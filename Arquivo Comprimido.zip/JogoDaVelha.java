import javafx.application.*;

import javafx.event.*;

import javafx.scene.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.canvas.*;
import javafx.scene.image.*;
import javafx.scene.paint.Color;

import javafx.stage.*;

import java.net.*;

import java.io.*;

import java.lang.*;
  
public class JogoDaVelha extends Application {
    public static void main(String[] args) throws UnknownHostException, IOException
    {
        launch();
    }

    public class Posicao
    {
        int lin;
        int col;

        public Posicao(double x, double y)
        {
            this.col = (int)Math.ceil(x/200);
            this.lin = (int)Math.ceil(y/200);
        }
    }

    
     
    public void start(Stage primaryStage) 
    {

        class Table implements EventHandler<ActionEvent>
        {
            public void handle(ActionEvent event)
            {
                //Text portNumberToOpen = new Text(porta.getText());

                Text nomeDoJogo = new Text();
                nomeDoJogo.setText("Jogo da Velha");

                Image table = new Image("table.png");
                ImageView imgView = new ImageView(table);

                VBox vboxTable = new VBox();
                //vboxTable.getChildren().add(nomeDoJogo);
                vboxTable.getChildren().add(imgView);

                // test
                //vboxTable.getChildren().add(portNumberToOpen);

                Scene telaTable = new Scene(vboxTable, 600, 600);
                telaTable.setOnMousePressed(eventMousePress -> {
                    Posicao p = new Posicao(eventMousePress.getX(), eventMousePress.getY());
                    System.out.println("X: " + p.lin + " Y: " + p.col);
                });
                primaryStage.setScene(telaTable);
                primaryStage.show();
            }
        }

        primaryStage.setTitle("Jogo da Velha");

        // VBox principal
        VBox root = new VBox();

        // HBox que contem o logo
        HBox logo = new HBox();
        Text t = new Text();
        t.setText("Jogo da Velha"); // Logo
        logo.getChildren().add(t);
        

        // HBox para botoes
        HBox bottomLine = new HBox();

        // Botao para ser host
        Button host = new Button();
		host.setText("Create");
		host.setOnAction(eventCreate ->
		{
			Text digitePorta = new Text();
            digitePorta.setText("Digite a porta"); 

            TextField porta = new TextField();

            Button iniciar = new Button();
            iniciar.setText("Begin Game!");
            iniciar.setOnAction(new Table());       // Tela jogo

            VBox vboxInicioHost = new VBox();
            vboxInicioHost.getChildren().addAll(digitePorta, porta, iniciar);

            Scene telaInicioHost = new Scene(vboxInicioHost, 600, 600);
            primaryStage.setScene(telaInicioHost);
            primaryStage.show();
		});
		
        // Botao para ser client
		Button client = new Button();
		client.setText("Join!");
		client.setOnAction(event ->
		{
			Text digiteIP = new Text();
            digiteIP.setText("Digite o IP do host:");

            TextField ipDoHost = new TextField();

            Text digitePortaDoHost = new Text();
            digitePortaDoHost.setText("Digite a porta do host:");

            TextField portaDoHost = new TextField();

            Button connect = new Button();
            connect.setText("Connect!");
            connect.setOnAction(new Table());       // Tela jogo

            VBox vboxTelaInicioClient = new VBox();
            vboxTelaInicioClient.getChildren().addAll(digiteIP, ipDoHost, digitePortaDoHost, portaDoHost, connect);

            Scene telaInicioClient = new Scene(vboxTelaInicioClient, 600, 600);
            primaryStage.setScene(telaInicioClient);
            primaryStage.show();
		});

        bottomLine.getChildren().add(host); 
        bottomLine.getChildren().add(client); 

        // Adicionando HBoxes na VBox principal
        root.getChildren().add(logo);
        root.getChildren().add(bottomLine);

        Scene scene = new Scene(root, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}